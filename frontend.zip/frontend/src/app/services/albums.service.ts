import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

export interface Album {
  
}

@Injectable({
  providedIn: 'root'
})
export class AlbumService {}
